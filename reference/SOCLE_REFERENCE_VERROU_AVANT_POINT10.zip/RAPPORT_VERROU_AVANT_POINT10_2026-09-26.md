# SOCLE — VERROU CIBLÉ AVANT POINT 10

Date : 26 septembre 2026
Base : `SOCLE_b990_STABILISE_AVANT_POINT10_2026-09-26.zip`
Objet : vérifier dans le code les alertes du contre-audit externe et corriger uniquement les défauts reproductibles.

## Verdict

Le contre-audit était crédible comme liste de vérification, mais plusieurs points étaient seulement « non démontrés ». Le contrôle direct du code a confirmé quatre défauts fonctionnels/sécurité, un problème de limite de stockage D1 et un N+1 principal. Ils ont été corrigés sans commencer Point 10.

## Corrections appliquées

1. `POST /api/expenses` : ajout d'une clé d'idempotence obligatoire, replay sûr et conflit 409 si la même clé est réutilisée avec d'autres données.
2. Documents : une clé d'idempotence réutilisée avec un fichier différent est maintenant refusée (SHA-256/taille/nom contrôlés) au lieu de rejouer silencieusement le premier document.
3. Documents liés à un devis : résolution de `quotes_server`, respect du `project_access`, et exigence de `quotes.view` + `quotes.prices.view` pour les non-OWNER. Un ouvrier sans droit prix ne peut pas télécharger le PDF du devis.
4. `/api/expenses` : les champs `allocatedCents`, `remainingCents`, `allocationCount` ne sont plus exposés sans `supplier_allocations.view`.
5. N+1 dépenses/ventilations : remplacement du calcul allocation par dépense par une agrégation SQL jointe.
6. Stockage documentaire D1 : la limite locale de 8 MiB était incompatible avec la limite D1 actuelle de 2 000 000 octets par BLOB/ligne. Limite SOCLE temporairement ramenée à 1 800 000 octets avec marge. Une migration vers stockage objet privé (ex. R2) reste nécessaire avant d'accepter de gros documents.
7. Erreurs serveur : les erreurs 5xx ne renvoient plus directement `error.message` au navigateur.
8. Frontend dépôt dépense : clé d'opération stable conservée sur le formulaire pendant un retry.
9. Migration `0017_pre_point10_lock.sql` : colonne/index d'idempotence dépenses. Les migrations 0000–0016 restent inchangées.

## Points vérifiés sans correctif

- FormData : déjà corrigé. `serverJson()` ne force pas `Content-Type: application/json` lorsque le body est un `FormData`.
- E-mail partenaire : l'acceptation utilise `oai-authenticated-user-email`, donc une valeur issue du contexte d'authentification serveur, pas un champ libre du payload.
- Dépense + document : deux requêtes HTTP restent nécessaires. L'UI n'annonce le succès qu'après les deux. Une machine d'état/compensation reste une amélioration future.
- `workspace_state` : dette historique toujours présente mais non aggravée.
- Migration complète des anciens devis vers `quotes_server` : non implémentée dans ce verrou ; à planifier comme migration explicite après inventaire des formes legacy, plutôt que convertir des données à l'aveugle.
- N+1 Documents : encore présent dans la liste globale de documents (relations chargées document par document). Dette performance, pas blocage fonctionnel Point 10.
- CSP : `unsafe-inline` reste présent ; retrait progressif nécessaire.

## Validation

- 25 suites non-navigateur exécutées.
- 835 assertions réussies.
- 0 échec dans ces suites.
- Build : `Worker and interface built.`
- `local-auth-required-15.mjs` : NON EXÉCUTÉ jusqu'aux assertions, chemin Node historique `/opt/nvm/versions/node/v22.16.0/bin/node` absent.
- `browser-identities-15.mjs` : 0 assertion, CDP `127.0.0.1:9222` indisponible.
- `browser-15.mjs` : 0 assertion, CDP `127.0.0.1:9222` indisponible.

Les tests navigateur ne sont donc pas déclarés réussis.

## Conclusion

La base corrigée est un verrou plus sûr avant Point 10. Point 10 n'a pas été commencé. Les dettes restantes (E2E réel, stockage objet privé pour gros documents, extinction progressive de `workspace_state`, N+1 Documents, retrait `unsafe-inline`, migration legacy des anciens devis) restent explicitement ouvertes.
